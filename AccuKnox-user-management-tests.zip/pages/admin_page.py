from playwright.sync_api import Page

class AdminPage:
    def __init__(self, page: Page):
        self.page = page
        self.admin_tab = page.get_by_role("link", name="Admin")
        self.add_btn = page.get_by_role("button", name="Add")
        self.search_username = page.locator("input[placeholder='Username']")
        self.search_btn = page.get_by_role("button", name="Search")
        self.save_btn = page.get_by_role("button", name="Save")

    def open_admin(self):
        self.admin_tab.click()
        self.page.wait_for_timeout(1000)

    def add_user(self, employee_name: str, username: str, password: str = "Admin123!"):
        self.add_btn.click()
        # fill employee name and choose first suggestion
        emp = self.page.locator("input[placeholder='Employee Name']")
        emp.fill(employee_name)
        self.page.wait_for_timeout(500)
        # press Enter to select first suggestion
        emp.press("Enter")
        self.page.locator("input[placeholder='Username']").fill(username)
        # set status to Enabled
        # fill password fields
        pw_fields = self.page.locator("input[type='password']")
        pw_fields.nth(0).fill(password)
        pw_fields.nth(1).fill(password)
        self.save_btn.click()
        self.page.wait_for_timeout(1000)

    def search_user(self, username: str):
        self.search_username.fill(username)
        self.search_btn.click()
        self.page.wait_for_timeout(1000)

    def edit_user_status(self, username: str, status_label: str = "Disabled"):
        # search and click edit
        self.search_user(username)
        # click edit icon of first row
        self.page.locator("button[title='Edit']").first.click()
        # change status by clicking label text
        self.page.get_by_text(status_label).click()
        self.save_btn.click()
        self.page.wait_for_timeout(800)

    def delete_user(self, username: str):
        self.search_user(username)
        # select the checkbox of first result
        checkbox = self.page.locator("input[type='checkbox']").nth(1)
        checkbox.check()
        self.page.get_by_role("button", name="Delete").click()
        # confirm dialog
        self.page.get_by_role("button", name="Yes, Delete").click()
        self.page.wait_for_timeout(1000)
