# Test Cases - User Management (OrangeHRM)

| Test Scenario | Pre-conditions | Test Steps | Test Data | Expected Result |
|---|---|---|---|---|
| Navigate to Admin Module | Logged in as Admin | 1. Login as Admin 2. Click Admin | Admin/admin123 | Admin dashboard opens |
| Add a New User | On Admin -> User Management | 1. Click Add 2. Fill Employee Name 3. Username 4. Set Status 5. Password 6. Save | Username: testuser123 | New user appears in list |
| Search Newly Created User | User created | 1. Enter username in search 2. Click Search | testuser123 | Matching user shown |
| Edit User Details | User exists | 1. Click Edit 2. Change Status 3. Save | Status: Disabled | Updated status visible |
| Validate Updated Details | Edit performed | 1. Search user 2. Verify status | testuser123 | Status shows Disabled |
| Delete the User | User exists | 1. Select checkbox 2. Click Delete 3. Confirm | testuser123 | User removed; No Records Found |
