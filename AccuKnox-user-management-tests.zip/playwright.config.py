# Minimal config for Playwright + pytest
# This project uses playwright's sync API in tests.
