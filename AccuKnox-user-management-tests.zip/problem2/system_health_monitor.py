#!/usr/bin/env python3
"""
Simple System Health Monitor
Checks CPU, memory, disk and logs alerts when thresholds exceeded.
"""
import psutil
import argparse
import time

CPU_THRESHOLD = 80.0
MEM_THRESHOLD = 80.0
DISK_THRESHOLD = 90.0

def check_system(cpu_thr=CPU_THRESHOLD, mem_thr=MEM_THRESHOLD, disk_thr=DISK_THRESHOLD):
    cpu = psutil.cpu_percent(interval=1)
    mem = psutil.virtual_memory().percent
    disk = psutil.disk_usage('/').percent

    alerts = []
    print(f"CPU: {cpu}% | Memory: {mem}% | Disk: {disk}%")

    if cpu > cpu_thr:
        alerts.append(f"High CPU usage: {cpu}%")
    if mem > mem_thr:
        alerts.append(f"High Memory usage: {mem}%")
    if disk > disk_thr:
        alerts.append(f"High Disk usage: {disk}%")

    # top 5 processes by CPU
    procs = []
    for p in psutil.process_iter(['pid','name','cpu_percent']):
        try:
            procs.append((p.info['pid'], p.info['name'], p.info['cpu_percent']))
        except Exception:
            continue
    procs_sorted = sorted(procs, key=lambda x: x[2] or 0, reverse=True)[:5]

    print("Top processes by CPU:")
    for pid, name, cpu_p in procs_sorted:
        print(f"PID {pid} - {name} - CPU {cpu_p}%")

    if alerts:
        print("ALERTS:")
        for a in alerts:
            print(" - ", a)
        # write to log file
        with open('system_health_alerts.log', 'a') as fh:
            fh.write(f"{time.ctime()} - " + "; ".join(alerts) + "\n")

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--cpu', type=float, default=CPU_THRESHOLD)
    parser.add_argument('--mem', type=float, default=MEM_THRESHOLD)
    parser.add_argument('--disk', type=float, default=DISK_THRESHOLD)
    args = parser.parse_args()
    check_system(args.cpu, args.mem, args.disk)
