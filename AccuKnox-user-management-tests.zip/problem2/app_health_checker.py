#!/usr/bin/env python3
"""
Simple Application Health Checker
Checks URL status code and basic content check.
"""
import requests
import argparse

def check_app(url: str, timeout: int = 5):
    try:
        r = requests.get(url, timeout=timeout)
        status = r.status_code
        print(f"{url} returned status {status}")
        if status == 200:
            print("Application is UP")
            return True
        else:
            print("Application is DOWN or returning non-200 status")
            return False
    except requests.RequestException as e:
        print("Application is DOWN — exception:", e)
        return False

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--url', required=True)
    parser.add_argument('--timeout', type=int, default=5)
    args = parser.parse_args()
    check_app(args.url, args.timeout)
