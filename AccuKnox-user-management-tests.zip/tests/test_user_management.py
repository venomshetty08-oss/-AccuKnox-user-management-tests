from playwright.sync_api import sync_playwright
from pages.login_page import LoginPage
from pages.admin_page import AdminPage
import uuid

ADMIN_URL = "https://opensource-demo.orangehrmlive.com/"

def test_user_management_flow():
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        page = browser.new_page()
        page.goto(ADMIN_URL)

        login = LoginPage(page)
        admin = AdminPage(page)

        # Login
        login.login("Admin", "admin123")

        # Open Admin module
        admin.open_admin()

        # Generate unique username
        username = f"testuser_{str(uuid.uuid4())[:8]}"

        # Add user
        admin.add_user("Paul Collings", username)

        # Search user
        admin.search_user(username)

        # Edit user (toggle Disabled)
        admin.edit_user_status(username, status_label="Disabled")

        # Validate update by searching again
        admin.search_user(username)

        # Delete user
        admin.delete_user(username)

        # Final search to validate deletion
        admin.search_user(username)
        # Optionally assert "No Records Found" is visible

        browser.close()
